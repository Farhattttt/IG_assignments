/**
 * 
 */
/**
 * 
 */
module week1solution {
}