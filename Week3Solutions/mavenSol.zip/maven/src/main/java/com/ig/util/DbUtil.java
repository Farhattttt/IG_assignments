package com.ig.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.io.InputStream;
import java.io.IOException;

public class DbUtil {
    private static Connection connection;

    static {
        try {
            // Load the properties file from the classpath
            InputStream input = DbUtil.class.getClassLoader().getResourceAsStream("db.properties");

            if (input == null) {
                throw new IOException("db.properties file not found in classpath!");
            }

            Properties properties = new Properties();
            properties.load(input);

            // Retrieve values correctly
            String driver = properties.getProperty("db.driver");
            String url = properties.getProperty("db.url");
            String username = properties.getProperty("db.username");
            String password = properties.getProperty("db.password");

            // Load MySQL Driver
            Class.forName(driver);

            // Establish connection
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Database connection established successfully!");

        } catch (IOException | ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Database connection failed!", e);
        }
    }

    public static Connection getConnection() {
        return connection;
    }
}
