package week1solution;

import week1solution.LowBalanceException;
import week1solution.InvalidAmountException;

public class Account {
	private Integer accNumber;
    private String custName;
    private AccountType type;
    private Float balance;

    // Constructor for Account
    public Account(Integer accNumber, String custName, AccountType type, Float balance) throws LowBalanceException, InvalidAmountException {
        this.accNumber = accNumber;
        this.custName = custName;
        this.type = type;
        
        if (balance < 0) {
            throw new InvalidAmountException("Balance cannot be negative.");
        }

        if (type == AccountType.SAVINGS && balance < 1000) {
            throw new LowBalanceException("Balance cannot be less than Rs. 1000 for Savings account.");
        }

        if (type == AccountType.CURRENT && balance < 5000) {
            throw new LowBalanceException("Balance cannot be less than Rs. 5000 for Current account.");
        }

        this.balance = balance;
    }

    // Getters and setters
    public Integer getAccNumber() {
        return accNumber;
    }

    public String getCustName() {
        return custName;
    }

    public AccountType getType() {
        return type;
    }

    public Float getBalance() {
        return balance;
    }

    public void setBalance(Float balance) {
        this.balance = balance;
    }
}
