package week1solution;

public enum AccountType {
    SAVINGS, CURRENT;
}
