package com.ig.service;

import com.ig.dao.ScholarDao;
import com.ig.exception.ScholarNotFoundException;
import com.ig.model.Scholar;

import java.sql.SQLException;
import java.util.List;

public class ScholarService {
    private ScholarDao scholarDao;

    public ScholarService() {
        this.scholarDao = new ScholarDao();
    }

    public void addScholar(Scholar scholar) throws SQLException {
        scholarDao.addScholar(scholar);
    }

    public Scholar getScholarById(int scholarId) throws SQLException, ScholarNotFoundException {
        return scholarDao.getScholarById(scholarId);
    }

    public List<Scholar> getAllScholars() throws SQLException {
        return scholarDao.getAllScholars();
    }

    public void updateScholarEmail(int scholarId, String newEmail) throws SQLException, ScholarNotFoundException {
        scholarDao.updateScholarEmail(scholarId, newEmail);
    }

    public void deleteScholarById(int scholarId) throws SQLException, ScholarNotFoundException {
        scholarDao.deleteScholarById(scholarId);
    }
}

