package week1solution;

import week1solution.Account;
import week1solution.AccountType;
import week1solution.AccountNotFoundException;
import week1solution.InsufficientFundsException;
import week1solution.InvalidAmountException;
import java.util.ArrayList;
import java.util.List;

public class AccountService {
	private List<Account> accountList = new ArrayList<>();

   
    public AccountService() {
        try {
            accountList.add(new Account(1001, "John Doe", AccountType.SAVINGS, 1500f));
            accountList.add(new Account(1002, "Jane Smith", AccountType.CURRENT, 6000f));
            accountList.add(new Account(1003, "Bob Brown", AccountType.SAVINGS, 1200f));
            accountList.add(new Account(1004, "Alice Green", AccountType.CURRENT, 8000f));
            accountList.add(new Account(1005, "Charlie White", AccountType.SAVINGS, 2000f));
        } catch (Exception e) {
            System.out.println("Error initializing account list: " + e.getMessage());
        }
    }

    
    public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                return true;
            }
        }
        throw new AccountNotFoundException("Account not found.");
    }

   
    public void deposit(int accNumber, float amt) throws InvalidAmountException, AccountNotFoundException {
        if (amt < 0) {
            throw new InvalidAmountException("Cannot deposit a negative amount.");
        }
        
        Account account = findAccount(accNumber);
        account.setBalance(account.getBalance() + amt);
    }

   
    public void withdraw(int accNumber, float amt) throws InvalidAmountException, InsufficientFundsException, AccountNotFoundException {
        if (amt < 500) {
            throw new InvalidAmountException("Withdrawal amount must be at least Rs. 500.");
        }

        Account account = findAccount(accNumber);
        if (account.getType() == AccountType.SAVINGS && account.getBalance() - amt < 1000) {
            throw new InsufficientFundsException("Insufficient funds for Savings account. Minimum balance required Rs. 1000.");
        }

        if (account.getType() == AccountType.CURRENT && account.getBalance() - amt < 5000) {
            throw new InsufficientFundsException("Insufficient funds for Current account. Minimum balance required Rs. 5000.");
        }

        account.setBalance(account.getBalance() - amt);
    }

  
    private Account findAccount(int accNumber) throws AccountNotFoundException {
        for (Account account : accountList) {
            if (account.getAccNumber() == accNumber) {
                return account;
            }
        }
        throw new AccountNotFoundException("Account not found.");
    }

    
    public float getBalance(int accNumber) throws AccountNotFoundException {
        Account account = findAccount(accNumber);
        return account.getBalance();
    }
}
