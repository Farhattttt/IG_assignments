package week1solution;

import week1solution.AccountService;
import week1solution.InvalidAmountException;
import week1solution.InsufficientFundsException;
import week1solution.AccountNotFoundException;

public class AccountTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AccountService accountService = new AccountService();

        try {
            // Test deposit
            accountService.deposit(1001, 500f);
            System.out.println("Deposited successfully to Account 1001.");

            // Test withdraw
            accountService.withdraw(1002, 2000f);
            System.out.println("Withdrawn successfully from Account 1002.");

            // Test balance check
            float balance = accountService.getBalance(1003);
            System.out.println("Account 1003 balance: " + balance);

        } catch (AccountNotFoundException | InvalidAmountException | InsufficientFundsException e) {
            System.out.println(e.getMessage());
        }
    }

	

}
